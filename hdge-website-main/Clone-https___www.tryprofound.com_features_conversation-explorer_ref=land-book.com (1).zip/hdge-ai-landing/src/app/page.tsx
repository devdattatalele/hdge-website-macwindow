import Header from "@/components/layout/Header";
import HeroSection from "@/components/layout/HeroSection";
import FeatureGrid from "@/components/features/FeatureGrid";
import Footer from "@/components/layout/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white">
      <Header />
      <HeroSection />
      <FeatureGrid />
      <Footer />
    </main>
  );
}
