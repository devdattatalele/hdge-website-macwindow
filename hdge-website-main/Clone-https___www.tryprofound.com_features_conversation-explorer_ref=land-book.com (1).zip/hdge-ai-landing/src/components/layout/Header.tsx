"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-sm border-b border-gray-800">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/" className="flex items-center">
            <span className="text-xl font-bold text-white mr-2">HDGE3</span>
            <span className="text-xl font-bold text-blue-400">LABS</span>
          </Link>
        </div>
        <nav className="hidden md:flex items-center space-x-8">
          <div className="relative group">
            <Link href="#platform" className="text-gray-300 hover:text-white transition-colors flex items-center">
              Platform
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1"><path d="m6 9 6 6 6-6"/></svg>
            </Link>
          </div>
          <div className="relative group">
            <Link href="#resources" className="text-gray-300 hover:text-white transition-colors flex items-center">
              Resources
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1"><path d="m6 9 6 6 6-6"/></svg>
            </Link>
          </div>
          <Link href="#enterprise" className="text-gray-300 hover:text-white transition-colors">
            Enterprise
          </Link>
          <Link href="#pricing" className="text-gray-300 hover:text-white transition-colors">
            Pricing
          </Link>
          <Link href="#careers" className="text-gray-300 hover:text-white transition-colors">
            Careers
          </Link>
        </nav>
        <div className="flex items-center space-x-4">
          <Button variant="ghost" className="hidden md:inline-flex text-gray-300 hover:text-white hover:bg-gray-800">
            Log in
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-500 text-white">
            Get started
          </Button>
        </div>
      </div>
    </header>
  );
}
