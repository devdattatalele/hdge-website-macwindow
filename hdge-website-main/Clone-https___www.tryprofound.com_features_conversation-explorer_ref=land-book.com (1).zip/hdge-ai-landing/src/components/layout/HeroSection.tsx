"use client";

import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions
    const setCanvasDimensions = () => {
      const containerWidth = canvas.parentElement?.clientWidth || window.innerWidth;
      const size = Math.min(containerWidth, 600);
      canvas.width = size;
      canvas.height = size;
    };

    setCanvasDimensions();
    window.addEventListener('resize', setCanvasDimensions);

    // Animation variables
    const points: { x: number; y: number; z: number }[] = [];
    const numPoints = 800;
    const radius = canvas.width * 0.4;

    // Create points on a sphere
    for (let i = 0; i < numPoints; i++) {
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);

      const x = radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.sin(phi) * Math.sin(theta);
      const z = radius * Math.cos(phi);

      points.push({ x, y, z });
    }

    let rotation = 0;

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Rotate points
      rotation += 0.001;

      for (const point of points) {
        // Apply rotation
        const x = point.x * Math.cos(rotation) - point.z * Math.sin(rotation);
        const z = point.x * Math.sin(rotation) + point.z * Math.cos(rotation);

        // Project 3D point to 2D
        const scale = 800 / (800 + z);
        const projectedX = x * scale + canvas.width / 2;
        const projectedY = point.y * scale + canvas.height / 2;

        // Draw point
        const opacity = (z + radius) / (2 * radius);
        ctx.fillStyle = `rgba(255, 255, 255, ${opacity * 0.8})`;
        ctx.beginPath();
        ctx.arc(projectedX, projectedY, 1, 0, Math.PI * 2);
        ctx.fill();
      }

      requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', setCanvasDimensions);
    };
  }, []);

  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden bg-black">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-[500px] bg-blue-900/20 rounded-full blur-3xl transform translate-y-[-50%] z-0"></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-20">
          <div className="mb-4 text-blue-400 font-semibold">Introducing HDGE AI</div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">
            <span className="gradient-text">Where Chatbots Get Down to<br className="hidden md:block" /> Business.</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
            All your Team needs a Great AI that understands your business, tracks data, and delivers personalized support, 24/7.
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center mb-12">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-500 text-white text-lg px-8 py-6 h-auto pulse-glow">
              Explore
            </Button>
            <Button size="lg" variant="outline" className="border-blue-500 text-blue-400 hover:bg-blue-950/50 text-lg px-8 py-6 h-auto">
              Book a Demo
            </Button>
          </div>
        </div>

        <div className="flex justify-center">
          <div className="relative animated-float">
            <canvas ref={canvasRef} className="w-full max-w-xl mx-auto"></canvas>
          </div>
        </div>

        <div className="mt-20 max-w-3xl mx-auto text-center">
          <p className="text-lg text-gray-400 animated-float">
            From handling customer inquiries to automating workflows. HdgeAI delivers intelligent, real-time responses that enhance customer satisfaction and streamline operations.
          </p>
        </div>
      </div>
    </section>
  );
}
