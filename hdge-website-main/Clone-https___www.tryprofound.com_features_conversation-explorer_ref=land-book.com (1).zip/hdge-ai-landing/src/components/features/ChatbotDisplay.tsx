"use client";

import { useState, useEffect } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface Message {
  sender: 'user' | 'ai';
  text: string;
  sentiment?: string;
}

interface Conversation {
  name: string;
  avatar: string;
  time: string;
  lastMessage: string;
  messages: Message[];
}

export default function ChatbotDisplay() {
  const [activeChat, setActiveChat] = useState(0);
  const [typing, setTyping] = useState(false);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [visibleMessages, setVisibleMessages] = useState<Message[]>([]);

  useEffect(() => {
    const messages = conversations[activeChat].messages;
    setVisibleMessages([messages[0]]);
    setCurrentMessageIndex(1);

    const timer = setTimeout(() => {
      setTyping(true);

      const typingTimer = setTimeout(() => {
        setTyping(false);
        setVisibleMessages([messages[0], messages[1]]);
        setCurrentMessageIndex(2);

        const nextTimer = setTimeout(() => {
          if (messages.length > 2) {
            setTyping(true);

            const finalTimer = setTimeout(() => {
              setTyping(false);
              setVisibleMessages([messages[0], messages[1], messages[2]]);
              setCurrentMessageIndex(3);
            }, 2000);

            return () => clearTimeout(finalTimer);
          }
        }, 1500);

        return () => clearTimeout(nextTimer);
      }, 2000);

      return () => clearTimeout(typingTimer);
    }, 1000);

    return () => clearTimeout(timer);
  }, [activeChat]);

  return (
    <div className="rounded-lg border border-gray-800 bg-gray-900 overflow-hidden h-[600px] shadow-2xl">
      <div className="flex h-full">
        {/* Left sidebar */}
        <div className="w-1/4 border-r border-gray-800 h-full hidden md:block">
          <div className="p-4 border-b border-gray-800">
            <div className="relative">
              <input
                type="text"
                placeholder="Search conversations"
                className="w-full bg-gray-800 text-gray-300 text-sm rounded-md px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 absolute right-3 top-2.5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          <div className="overflow-y-auto h-[calc(100%-60px)]">
            {conversations.map((conversation, index) => (
              <div
                key={index}
                onClick={() => setActiveChat(index)}
                className={`p-4 border-b border-gray-800 cursor-pointer hover:bg-gray-800 transition-colors ${activeChat === index ? 'bg-gray-800' : ''}`}
              >
                <div className="flex items-start">
                  <Avatar className="h-8 w-8 mr-3">
                    <AvatarImage src={conversation.avatar} alt={conversation.name} />
                    <AvatarFallback>{conversation.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-white truncate">{conversation.name}</p>
                      <span className="text-xs text-gray-500">{conversation.time}</span>
                    </div>
                    <p className="text-xs text-gray-400 truncate mt-1">
                      {conversation.lastMessage}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Main chat area */}
        <div className="flex-1 flex flex-col">
          {/* Chat header */}
          <div className="p-4 border-b border-gray-800 flex items-center justify-between">
            <div className="flex items-center">
              <Avatar className="h-8 w-8 mr-3">
                <AvatarImage src={conversations[activeChat].avatar} alt={conversations[activeChat].name} />
                <AvatarFallback>{conversations[activeChat].name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium text-white">{conversations[activeChat].name}</p>
                <div className="flex items-center">
                  <span className="h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                  <span className="text-xs text-gray-400">Online</span>
                </div>
              </div>
            </div>
            <div className="flex space-x-3">
              <button className="text-gray-400 hover:text-white transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M15.6 11.6L22 7v10l-6.4-4.5v-1zM4 5h9a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7c0-1.1.9-2 2-2z" />
                </svg>
              </button>
              <button className="text-gray-400 hover:text-white transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                </svg>
              </button>
              <button className="text-gray-400 hover:text-white transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="1" />
                  <circle cx="19" cy="12" r="1" />
                  <circle cx="5" cy="12" r="1" />
                </svg>
              </button>
            </div>
          </div>

          {/* Chat messages */}
          <div className="flex-1 p-4 overflow-y-auto bg-gray-950">
            {visibleMessages.map((message, index) => (
              <div key={index} className={`mb-4 flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                {message.sender !== 'user' && (
                  <Avatar className="h-8 w-8 mr-3 mt-1">
                    <AvatarImage src={conversations[activeChat].avatar} alt={conversations[activeChat].name} />
                    <AvatarFallback>{conversations[activeChat].name.charAt(0)}</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`max-w-[70%] px-4 py-2 rounded-lg ${
                    message.sender === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-800 text-gray-200'
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  {message.sentiment && (
                    <div className="mt-2 flex items-center justify-end">
                      <Badge variant="outline" className="text-xs border-green-500 text-green-400">
                        {message.sentiment}
                      </Badge>
                    </div>
                  )}
                </div>
                {message.sender === 'user' && (
                  <Avatar className="h-8 w-8 ml-3 mt-1">
                    <AvatarFallback className="bg-blue-700 text-white">U</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}

            {typing && (
              <div className="mb-4 flex justify-start">
                <Avatar className="h-8 w-8 mr-3 mt-1">
                  <AvatarImage src={conversations[activeChat].avatar} alt={conversations[activeChat].name} />
                  <AvatarFallback>{conversations[activeChat].name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="bg-gray-800 text-gray-200 px-4 py-3 rounded-lg">
                  <div className="flex space-x-1">
                    <div className="h-2 w-2 rounded-full bg-gray-500 animate-pulse"></div>
                    <div className="h-2 w-2 rounded-full bg-gray-500 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                    <div className="h-2 w-2 rounded-full bg-gray-500 animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Chat input */}
          <div className="p-4 border-t border-gray-800">
            <div className="flex items-center bg-gray-800 rounded-lg px-3 py-2">
              <button className="text-gray-400 mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                </svg>
              </button>
              <input
                type="text"
                placeholder="Type a message..."
                className="flex-1 bg-transparent text-white focus:outline-none text-sm px-2"
                disabled={typing}
              />
              <button className="text-gray-400 ml-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 8v4l2 2"></path>
                  <rect x="4" y="4" width="16" height="16" rx="2"></rect>
                </svg>
              </button>
              <button className="text-gray-400 ml-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M12 16v-4"></path>
                  <path d="M12 8h.01"></path>
                </svg>
              </button>
              <button className="text-blue-500 ml-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"></line>
                  <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
              </button>
            </div>

            {/* Analytics tag */}
            <div className="mt-3 flex justify-between items-center">
              <div className="flex items-center space-x-3">
                <Badge variant="outline" className="text-xs border-blue-500 text-blue-400">
                  AI Analysis
                </Badge>
                <span className="text-xs text-gray-500">Customer sentiment: Positive</span>
              </div>
              <button className="text-xs text-blue-400 hover:text-blue-300 transition-colors">
                View Details
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const conversations: Conversation[] = [
  {
    name: "Sarah Thompson",
    avatar: "https://ext.same-assets.com/avatars-blue-3-b5ef.jpg",
    time: "10:42 AM",
    lastMessage: "Thanks for your help with resolving the issue!",
    messages: [
      {
        sender: "user",
        text: "Hi, I'm having trouble setting up the API integration with my CRM system. Can you help?",
      },
      {
        sender: "ai",
        text: "Of course! I'd be happy to help you with the API integration. Could you tell me which CRM system you're using and what specific issue you're encountering?",
      },
      {
        sender: "user",
        text: "I'm using Salesforce, and I keep getting an authentication error when trying to connect using the API key provided.",
        sentiment: "Frustrated",
      },
    ],
  },
  {
    name: "Miguel Rodriguez",
    avatar: "https://ext.same-assets.com/avatars-blue-1-v112.jpg",
    time: "Yesterday",
    lastMessage: "I'll check on the status and get back to you.",
    messages: [
      {
        sender: "user",
        text: "Hello, when will the new analytics dashboard feature be available?",
      },
      {
        sender: "ai",
        text: "Hi Miguel! The new analytics dashboard is currently in final testing and should be released next Tuesday. Would you like me to notify you when it's available?",
      },
    ],
  },
  {
    name: "Jessica Lee",
    avatar: "https://ext.same-assets.com/avatars-blue-2-n9ks.jpg",
    time: "Mar 22",
    lastMessage: "The issue has been resolved.",
    messages: [
      {
        sender: "user",
        text: "I need to reset my team members' passwords. Where do I find that option?",
      },
      {
        sender: "ai",
        text: "You can reset team member passwords in the Admin Panel. Just go to Settings > User Management, select the team member, and click on 'Reset Password'. Would you like me to walk you through the steps?",
      },
    ],
  },
];
