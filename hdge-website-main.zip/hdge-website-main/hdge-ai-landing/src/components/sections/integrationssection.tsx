"use client";

import { motion } from "framer-motion";
import Image from "next/image";

const IntegrationsSection = () => {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center mb-16">
          <div className="inline-flex items-center justify-center px-4 py-1 mb-4 rounded-full bg-gray-800 shadow-sm">
            <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M8 17L12 21M12 21L16 17M12 21V12M20 16.7428C21.2215 15.734 22 14.2079 22 12.5C22 9.46243 19.5376 7 16.5 7C16.2815 7 16.0771 6.886 15.9661 6.69774C14.6621 4.48484 12.2544 3 9.5 3C5.35786 3 2 6.35786 2 10.5C2 12.5661 2.83545 14.4371 4.18695 15.7935" stroke="#A0AEC0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="text-sm font-medium text-gray-300">Integrations</span>
          </div>
          <h2 className="text-5xl font-bold text-center text-white mb-4">Integrates with</h2>
          <p className="text-xl text-gray-400 text-center max-w-2xl">
            Seamlessly integrate with your favorite tools
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto h-[600px]">
          {/* Central Logo */}
          <div 
          >
            <div className="bg-blue-900 rounded-xl p-6 shadow-xl w-[100px] h-[100px] ">
              <div className="w-12 h-12 relative">
                <Image 
                  src="/logo.png" 
                  alt="HDGE AI Logo" 
                  fill 
                  style={{ objectFit: 'contain' }} 
                />
              </div>
            </div>
          </div>

          {/* Left Icons Group - moved further left */}
          <div className="absolute left-[-80px] top-1/2 transform -translate-y-1/2 space-y-0">
            {/* LinkedIn - moved up by 1.5cm */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="bg-gray-800 rounded-xl shadow-lg p-5 w-[80px] h-[80px] flex justify-center items-center mb-[70px]"
              style={{ 
                boxShadow: "rgba(0, 0, 0, 0.4) 0px -3px 0px 2px inset, rgba(0, 0, 0, 0.3) 0px 1px 1px, rgba(0, 0, 0, 0.2) 0px 6px 10px",
                marginTop: "10px"
              }}
            >
              <svg width="40" height="40" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M216,24H40A16,16,0,0,0,24,40V216a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V40A16,16,0,0,0,216,24Zm0,192H40V40H216V216ZM96,112v64a8,8,0,0,1-16,0V112a8,8,0,0,1,16,0Zm88,28v36a8,8,0,0,1-16,0V140a20,20,0,0,0-40,0v36a8,8,0,0,1-16,0V112a8,8,0,0,1,15.79-1.78A36,36,0,0,1,184,140ZM100,84A12,12,0,1,1,88,72,12,12,0,0,1,100,84Z" fill="#A0AEC0"/>
              </svg>
            </motion.div>

            {/* Facebook */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="bg-gray-800 rounded-xl shadow-lg p-5 w-[80px] h-[80px] flex justify-center items-center mb-[50px]"
              style={{ 
                boxShadow: "rgba(0, 0, 0, 0.4) 0px -3px 0px 2px inset, rgba(0, 0, 0, 0.3) 0px 1px 1px, rgba(0, 0, 0, 0.2) 0px 6px 10px"
              }}
            >
              <svg width="40" height="40" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm8,191.63V152h24a8,8,0,0,0,0-16H136V112a16,16,0,0,1,16-16h16a8,8,0,0,0,0-16H152a32,32,0,0,0-32,32v24H96a8,8,0,0,0,0,16h24v63.63a88,88,0,1,1,16,0Z" fill="#A0AEC0"/>
              </svg>
            </motion.div>

            {/* Google - moved down further */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="bg-gray-800 rounded-xl shadow-lg p-5 w-[80px] h-[80px] flex justify-center items-center"
              style={{ 
                boxShadow: "rgba(0, 0, 0, 0.4) 0px -3px 0px 2px inset, rgba(0, 0, 0, 0.3) 0px 1px 1px, rgba(0, 0, 0, 0.2) 0px 6px 10px",
                marginTop: "120px"  // Increased from 40px to 120px (approximately 4cm more)
              }}
            >
              <svg width="40" height="40" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M224,128a96,96,0,1,1-21.95-61.09,8,8,0,1,1-12.33,10.18A80,80,0,1,0,207.6,136H128a8,8,0,0,1,0-16h88A8,8,0,0,1,224,128Z" fill="#A0AEC0"/>
              </svg>
            </motion.div>
          </div>

          {/* Right Icons Group - moved further right */}
          <div className="absolute right-[-80px] top-1/2 transform -translate-y-1/2 space-y-0">
            {/* Twitter */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="bg-gray-800 rounded-xl shadow-lg p-5 w-[80px] h-[80px] flex justify-center items-center mb-[70px]"
              style={{ 
                boxShadow: "rgba(0, 0, 0, 0.4) 0px -3px 0px 2px inset, rgba(0, 0, 0, 0.3) 0px 1px 1px, rgba(0, 0, 0, 0.2) 0px 6px 10px",
                marginTop: "10px"
              }}
            >
              <svg width="40" height="40" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M247.39,68.94A8,8,0,0,0,240,64H209.57A48.66,48.66,0,0,0,168.1,40a46.91,46.91,0,0,0-33.75,13.7A47.9,47.9,0,0,0,120,88v6.09C79.74,83.47,46.81,50.72,46.46,50.37a8,8,0,0,0-13.65,4.92c-4.31,47.79,9.57,79.77,22,98.18a110.93,110.93,0,0,0,21.88,24.2c-15.23,17.53-39.21,26.74-39.47,26.84a8,8,0,0,0-3.85,11.93c.75,1.12,3.75,5.05,11.08,8.72C53.51,229.7,65.48,232,80,232c70.67,0,129.72-54.42,135.75-124.44l29.91-29.9A8,8,0,0,0,247.39,68.94Zm-45,29.41a8,8,0,0,0-2.32,5.14C196,166.58,143.28,216,80,216c-10.56,0-18-1.4-23.22-3.08,11.51-6.25,27.56-17,37.88-32.48A8,8,0,0,0,92,169.08c-.47-.27-43.91-26.34-44-96,16,13,45.25,33.17,78.67,38.79A8,8,0,0,0,136,104V88a32,32,0,0,1,9.6-22.92A30.94,30.94,0,0,1,167.9,56c12.66.16,24.49,7.88,29.44,19.21A8,8,0,0,0,204.67,80h16Z" fill="#A0AEC0"/>
              </svg>
            </motion.div>

            {/* TikTok */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="bg-gray-800 rounded-xl shadow-lg p-5 w-[80px] h-[80px] flex justify-center items-center mb-[50px]"
              style={{ 
                boxShadow: "rgba(0, 0, 0, 0.4) 0px -3px 0px 2px inset, rgba(0, 0, 0, 0.3) 0px 1px 1px, rgba(0, 0, 0, 0.2) 0px 6px 10px"
              }}
            >
              <svg width="40" height="40" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M224,72a48.05,48.05,0,0,1-48-48,8,8,0,0,0-8-8H128a8,8,0,0,0-8,8V156a20,20,0,1,1-28.57-18.08A8,8,0,0,0,96,130.69V88a8,8,0,0,0-9.4-7.88C50.91,86.48,24,119.1,24,156a76,76,0,0,0,152,0V116.29A103.25,103.25,0,0,0,224,128a8,8,0,0,0,8-8V80A8,8,0,0,0,224,72Zm-8,39.64a87.19,87.19,0,0,1-43.33-16.15A8,8,0,0,0,160,102v54a60,60,0,0,1-120,0c0-25.9,16.64-49.13,40-57.6v27.67A36,36,0,1,0,136,156V32h24.5A64.14,64.14,0,0,0,216,87.5Z" fill="#A0AEC0"/>
              </svg>
            </motion.div>

            {/* GitHub */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="bg-gray-800 rounded-xl shadow-lg p-5 w-[80px] h-[80px] flex justify-center items-center"
              style={{ 
                boxShadow: "rgba(0, 0, 0, 0.4) 0px -3px 0px 2px inset, rgba(0, 0, 0, 0.3) 0px 1px 1px, rgba(0, 0, 0, 0.2) 0px 6px 10px",
                marginTop: "120px"
              }}
            >
              <svg width="40" height="40" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M208.31,75.68A59.78,59.78,0,0,0,202.93,28,8,8,0,0,0,196,24a59.75,59.75,0,0,0-48,24H124A59.75,59.75,0,0,0,76,24a8,8,0,0,0-6.93,4,59.78,59.78,0,0,0-5.38,47.68A58.14,58.14,0,0,0,56,104v8a56.06,56.06,0,0,0,48.44,55.47A39.8,39.8,0,0,0,96,192v8H72a24,24,0,0,1-24-24A40,40,0,0,0,8,136a8,8,0,0,0,0,16,24,24,0,0,1,24,24,40,40,0,0,0,40,40H96v16a8,8,0,0,0,16,0V192a24,24,0,0,1,48,0v40a8,8,0,0,0,16,0V192a39.8,39.8,0,0,0-8.44-24.53A56.06,56.06,0,0,0,216,112v-8A58.14,58.14,0,0,0,208.31,75.68ZM200,112a40,40,0,0,1-40,40H112a40,40,0,0,1-40-40v-8a41.74,41.74,0,0,1,6.9-22.48A8,8,0,0,0,80,73.83a43.81,43.81,0,0,1,.79-33.58,43.88,43.88,0,0,1,32.32,20.06A8,8,0,0,0,119.82,64h32.35a8,8,0,0,0,6.74-3.69,43.87,43.87,0,0,1,32.32-20.06A43.81,43.81,0,0,1,192,73.83a8.09,8.09,0,0,0,1,7.65A41.72,41.72,0,0,1,200,104Z" fill="#A0AEC0"/>
              </svg>
            </motion.div>
          </div>

          {/* Connection Lines */}
          <div className="absolute inset-0">
            {/* Left Top Connection - decreased size by 3% */}
            <svg 
              className="absolute top-[135px] left-0 w-[339.5px] h-[155.2px]" 
              viewBox="0 0 437 193" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M 0 1 L 122.022 1 C 130.298 1 137.01 7.702 137.022 15.978 L 137.175 122.029 C 137.187 130.302 143.895 137.003 152.168 137.007 L 275.007 137.066 C 283.289 137.07 290 143.785 290 152.066 L 290 177 C 290 185.284 296.716 192 305 192 L 437 192" 
                stroke="rgb(66, 153, 225)" 
                strokeMiterlimit="10" 
                strokeDasharray="5,3" 
              />
            </svg>

            {/* Left Bottom Connection - decreased size by 3% */}
            <svg 
              className="absolute bottom-[120px] left-0 w-[423.9px] h-[187.2px]" 
              viewBox="0 0 437 193" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M 0 192 L 122.022 192 C 130.298 192 137.01 185.298 137.022 177.022 L 137.175 70.971 C 137.187 62.698 143.906 55.997 152.179 55.993 L 274.996 55.933 C 283.278 55.93 290 49.215 290 40.933 L 290 16 C 290 7.716 296.716 1 305 1 L 437 1" 
                stroke="rgb(66, 153, 225)" 
                strokeMiterlimit="10" 
                strokeDasharray="5,3" 
              />
            </svg>

            {/* Right Top Connection - decreased size by 3% */}
            <svg 
              className="absolute top-[135px] right-0 w-[339.5px] h-[155.2px]" 
              viewBox="0 0 437 193" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M 437 1 L 314.978 1 C 306.702 1 299.99 7.702 299.978 15.978 L 299.825 122.029 C 299.813 130.302 293.105 137.003 284.832 137.007 L 161.993 137.066 C 153.711 137.07 147 143.785 147 152.066 L 147 177 C 147 185.284 140.284 192 132 192 L 0 192" 
                stroke="rgb(66, 153, 225)" 
                strokeMiterlimit="10" 
                strokeDasharray="5,3" 
              />
            </svg>
            
            {/* Right Bottom Connection - decreased size by 3% */}
            <svg 
              className="absolute bottom-[120px] right-0 w-[423.9px] h-[187.2px]" 
              viewBox="0 0 437 193" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M 437 192 L 314.978 192 C 306.702 192 299.99 185.298 299.978 177.022 L 299.825 70.971 C 299.813 62.698 293.105 55.997 284.832 55.993 L 161.993 55.933 C 153.711 55.93 147 49.215 147 40.933 L 147 16 C 147 7.716 140.284 1 132 1 L 0 1" 
                stroke="rgb(66, 153, 225)" 
                strokeMiterlimit="10" 
                strokeDasharray="5,3" 
              />
            </svg>
          </div>
        </div>

        {/* Features */}
        <div className="flex flex-wrap justify-center gap-10 mt-16">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-full bg-gray-800">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 16L12 8L4 16" stroke="#A0AEC0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <span className="text-gray-300 font-medium">Seamless Automation</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-full bg-gray-800">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="10" stroke="#A0AEC0" strokeWidth="2"/>
                <path d="M12 6V12L16 14" stroke="#A0AEC0" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <span className="text-gray-300 font-medium">Real-Time Data Sync</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-full bg-gray-800">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="#A0AEC0" strokeWidth="2"/>
                <path d="M19.4 15C19.1277 15.8031 19.2583 16.6718 19.7601 17.37C20.2619 17.9682 21.0377 18.3351 21.8601 18.34C21.9468 17.7418 21.9936 17.1375 22 16.53C22 16.19 21.97 15.86 21.92 15.53C21.2286 15.1987 20.4421 15.0889 19.6841 15.2121C19.5909 15.2268 19.4983 15.2486 19.4 15.28V15Z" stroke="#A0AEC0" strokeWidth="2"/>
                <path d="M19.94 8.18C19.6055 7.99806 19.2445 7.87549 18.87 7.82C18.5738 7.83538 18.2865 7.91057 18.03 8.04C17.7735 8.16944 17.5549 8.35091 17.39 8.57C17.1808 8.92316 17.0846 9.32736 17.1141 9.73324C17.1435 10.1391 17.2973 10.5225 17.5534 10.8334C17.8094 11.1444 18.1559 11.3667 18.5455 11.4692C18.9351 11.5717 19.3472 11.5495 19.7234 11.4059C20.0996 11.2622 20.4229 11.0036 20.65 10.67L20.75 10.5C20.75 9.9 20.75 9.4 20.75 9.12C20.5054 8.73539 20.1707 8.41772 19.77 8.2L19.94 8.18Z" stroke="#A0AEC0" strokeWidth="2"/>
                <path d="M8.34 17.69C8.5 18.11 8.28 18.12 8.23 18.12C7.45999 18.35 6.73 18.73 6.09 19.23C5.8113 19.4242 5.57177 19.6683 5.38 19.95C5.30296 20.2743 5.27528 20.6083 5.29823 20.9402C5.32118 21.2721 5.39448 21.5979 5.51 21.91C6.0075 21.8307 6.48192 21.6371 6.89 21.35C7.3372 21.0745 7.73257 20.7253 8.06 20.32C8.45113 19.8112 8.7358 19.2336 8.89 18.62L9 18.12L8.34 17.69Z" stroke="#A0AEC0" strokeWidth="2"/>
                <path d="M4.59 12.22C4.95 12.22 5.08 12.05 5.11 11.88C5.2045 11.3268 5.15498 10.7623 4.97 10.23C4.77 9.69 4.3 8.94 3.92 8.55C3.7 8.33 3.42 8.15 3.13 8.05C2.5 7.85 2.2 8.05 2.06 8.24C1.89 8.47 1.89 8.79 2.06 9.26C2.23 9.73 2.4 10.24 2.78 10.76C3.16 11.28 3.59 11.78 4.11 12.11L4.59 12.22Z" stroke="#A0AEC0" strokeWidth="2"/>
              </svg>
            </div>
            <span className="text-gray-300 font-medium">Customizable Solutions</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IntegrationsSection;