"use client";

import { useRef, useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import ChatbotDisplay from "./ChatbotDisplay";

export default function FeatureGrid() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const chatbotRef = useRef<HTMLDivElement>(null);
  const [scrollPosition, setScrollPosition] = useState(0);

  // Animation for feature cards
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("opacity-100", "translate-y-0");
            entry.target.classList.remove("opacity-0", "translate-y-8");
          }
        });
      },
      { threshold: 0.1 }
    );

    const featureCards = document.querySelectorAll(".feature-card");
    featureCards.forEach((card) => {
      card.classList.add("opacity-0", "translate-y-8", "transition-all", "duration-700");
      observer.observe(card);
    });

    return () => {
      featureCards.forEach((card) => {
        observer.unobserve(card);
      });
    };
  }, []);

  // Horizontal scrolling animation for feature tags
  useEffect(() => {
    const animateScroll = () => {
      setScrollPosition((prevPosition) => {
        // Reset when it reaches a certain point to create infinite loop effect
        if (prevPosition <= -1000) {
          return 0;
        }
        return prevPosition - 1.5; // Adjust speed here
      });
    };

    const animationId = setInterval(animateScroll, 30);
    return () => clearInterval(animationId);
  }, []);

  // Feature tags for the scrolling animation
  const featureTags = [
    "24/7 Support", "Smart Analytics", "Personalized Responses", "Workflow Automation",
    "Real-time Insights", "Seamless Integration", "Customer Retention", "Data-Driven",
    "Cost-Effective", "Increased Efficiency",
    "Instant Resolution", "AI-Powered Assistance", "Scalable Solutions", "Intelligent Routing",
    "Enhanced Productivity", "Multi-Platform Support", "Proactive Engagement", "Customizable Workflows",
    "Actionable Recommendations", "Automated Reporting", "Dynamic Query Handling", "Optimized Operations",
    "User-Centric Design", "Predictive Analytics", "Adaptive Learning", "Seamless Collaboration",
    "Effortless Deployment", "Smart Knowledge Base", "Continuous Improvement", "Frictionless User Experience"
];


  // Duplicate tags to create seamless loop
  const allTags = [...featureTags, ...featureTags];

  return (
    <>
      <section ref={sectionRef} className="py-20 md:py-32 bg-gradient-dark overflow-hidden" id="features">
        <div className="container mx-auto px-4">
          {/* Updated heading section to be left-aligned */}
          <div className="mb-16">
            <Badge variant="outline" className="mb-4 border-blue-500 text-blue-400 py-1 px-3">Features</Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">Powerful AI Features</h2>
            <p className="text-lg text-gray-300 max-w-3xl">
              Enhance your customer support experience with our comprehensive suite of AI-powered tools
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card 
                key={index} 
                className="feature-card bg-gray-900 border-gray-800 hover:border-blue-500 transition-all duration-300 transform-gpu"
              >
                <CardContent className="p-6 relative z-10">
                  <div className="mb-4 text-blue-400">{feature.icon}</div>
                  <h3 className="text-xl font-bold mb-3 text-white">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Both scrolling feature tags sections moved together after the features grid */}
          <div className="mt-16 space-y-8">
            {/* First scrolling feature tags (moved from above) */}
            <div className="w-full overflow-hidden mask-gradient-x">
              <div 
                className="flex gap-8 py-2" 
                style={{ 
                  transform: `translateX(${scrollPosition}px)`,
                  width: "max-content"
                }}
              >
                {allTags.map((tag, index) => (
                  <div 
                    key={index} 
                    className="px-4 py-2 bg-gray-800 text-gray-300 rounded-full whitespace-nowrap"
                  >
                    {tag}
                  </div>
                ))}
              </div>
            </div>
            
            {/* Second scrolling feature tags */}
            <div className="w-full overflow-hidden mask-gradient-x">
              <div 
                className="flex gap-8 py-2" 
                style={{ 
                  transform: `translateX(${-scrollPosition}px)`,
                  width: "max-content"
                }}
              >
                {[...featureTags, ...featureTags].map((tag, index) => (
                  <div 
                    key={index} 
                    className="px-4 py-2 bg-gray-800 text-gray-300 rounded-full whitespace-nowrap"
                  >
                    {tag}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section ref={chatbotRef} className="py-20 md:py-32 bg-black overflow-hidden" id="conversationExplorer">
        {/* Rest of the component remains unchanged */}
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge variant="outline" className="mb-4 border-blue-500 text-blue-400 py-1 px-3">Conversation Explorer</Badge>
              <h2 className="text-3xl md:text-5xl font-bold mb-6 gradient-text">Analyze customer conversations at scale</h2>
              <p className="text-lg text-gray-300 mb-8">
                Uncover patterns, identify issues, and track sentiment to improve your customer experience.
                HdgeAI helps you understand what your customers are saying and how they're feeling.
              </p>

              <div className="space-y-6 mb-8">
                {[
                  { title: "Track conversation quality", description: "Monitor agent performance and customer satisfaction scores" },
                  { title: "Identify common issues", description: "Use AI to categorize and cluster similar customer problems" },
                  { title: "Optimize response times", description: "Analyze response times and identify bottlenecks in your process" },
                ].map((item, index) => (
                  <div key={index} className="flex">
                    <div className="flex-shrink-0 h-6 w-6 rounded-full bg-blue-500 flex items-center justify-center mr-4 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 text-white">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-white">{item.title}</h4>
                      <p className="text-gray-400">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Button className="bg-blue-600 hover:bg-blue-500 text-white">
                Learn more
              </Button>
            </div>

            <div className="lg:pl-8">
              <ChatbotDisplay />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

// Features array remains unchanged
const features = [
  {
    title: "24/7 Customer Support",
    description: "Provide instant support to your customers any time of day, resolving issues faster and improving satisfaction.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
        <path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12 6.5 2 12 2"></path>
        <path d="M12 2v20"></path>
        <path d="M2 12h20"></path>
        <path d="M20 18.6 18.6 17"></path>
        <path d="M20 5.4 18.6 7"></path>
        <path d="M4 18.6 5.4 17"></path>
        <path d="M4 5.4 5.4 7"></path>
      </svg>
    ),
  },
  {
    title: "Smart Data Tracking",
    description: "Automatically track and analyze customer data to identify trends and make data-driven decisions.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
        <path d="m22 12-9-9-2 2 7 7-7 7 2 2z"></path>
        <path d="M11 5 2 14l9 9"></path>
        <path d="m19 12-7-7"></path>
        <path d="m19 12-7 7"></path>
      </svg>
    ),
  },
  {
    title: "Personalized Responses",
    description: "Deliver tailored responses based on customer history, preferences, and behavior patterns.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
        <path d="M17 18a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2"></path>
        <rect width="18" height="18" x="3" y="3" rx="2"></rect>
        <circle cx="12" cy="10" r="3"></circle>
      </svg>
    ),
  },
  {
    title: "Workflow Automation",
    description: "Streamline operations by automating repetitive tasks and processes, allowing your team to focus on high-value work.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
        <path d="M12 22v-5"></path>
        <path d="M9 8V2"></path>
        <path d="M15 8V2"></path>
        <path d="M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8"></path>
        <path d="M12 17v-5"></path>
      </svg>
    ),
  },
  {
    title: "Real-time Analytics",
    description: "Monitor performance metrics and customer interactions in real-time to quickly identify and address issues.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
        <path d="M2 12h20"></path>
        <path d="M2 20h20"></path>
        <path d="M2 4h20"></path>
        <path d="M6 12v8"></path>
        <path d="M14 12v8"></path>
        <path d="M10 4v16"></path>
        <path d="M18 4v16"></path>
      </svg>
    ),
  },
  {
    title: "Seamless Integration",
    description: "Easily integrate with your existing tools and systems, from CRM to helpdesk software, for a unified workflow.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
        <path d="M16.5 9.4 7.5 4.21"></path>
        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
        <path d="M3.27 6.96 12 12.01l8.73-5.05"></path>
        <path d="M12 22.08V12"></path>
      </svg>
    ),
  },
];
