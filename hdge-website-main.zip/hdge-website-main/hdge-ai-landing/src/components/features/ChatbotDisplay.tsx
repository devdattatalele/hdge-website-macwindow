"use client";

import { useRef } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import ChatBot from "@/components/chat/chatbot";

export default function ChatbotDisplay() {
  // Using react-intersection-observer instead of framer-motion's useInView
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.3,
  });

  // Animation variants
  const chatbotVariants = {
    hidden: { 
      scale: 0.9, 
      opacity: 0,
      y: 50 
    },
    visible: { 
      scale: 1, 
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 100,
        duration: 0.8
      }
    }
  };

  // Create a mock conversation for the demo
  const demoMessages = [
    {
      id: "welcome",
      text: "Hi there! Welcome to HdgeAI! 👋\n\nHow can I help you today?",
      sender: "bot",
      timestamp: new Date()
    },
    {
      id: "user1",
      text: "I'm interested in using AI for my customer support team.",
      sender: "user",
      timestamp: new Date(Date.now() - 60000)
    },
    {
      id: "bot1",
      text: "That's a great use case! HdgeAI can help you automate responses to common questions, analyze customer sentiment, and provide insights to improve your support experience.",
      sender: "bot",
      timestamp: new Date(Date.now() - 30000)
    }
  ];

  return (
    <motion.div 
      ref={ref}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      variants={chatbotVariants}
      className="rounded-lg border border-gray-800 bg-gray-900 overflow-hidden h-[600px] shadow-2xl"
    >
      {/* Custom chat interface that mimics the ChatBot component */}
      <div className="w-full h-full bg-black border border-gray-700 rounded-lg shadow-xl flex flex-col overflow-hidden">
        {/* Chat header */}
        <div className="bg-gray-900 p-4 flex items-center border-b border-gray-700">
          <div>
            <div className="text-white font-medium">HdgeAI.space</div>
            <div className="text-xs text-green-400">Online</div>
          </div>
        </div>
        
        {/* Messages area */}
        <div className="flex-1 p-4 overflow-y-auto bg-gray-950">
          {demoMessages.map((message) => (
            <div
              key={message.id}
              className={`mb-4 flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.sender === "user"
                    ? "bg-blue-600 text-white"
                    : "bg-gray-800 text-white"
                }`}
              >
                <div className="whitespace-pre-wrap">{message.text}</div>
                <div className="text-xs mt-1 opacity-70">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Input area */}
        <div className="p-3 border-t border-gray-700 bg-gray-900">
          <div className="flex">
            <input
              type="text"
              placeholder="Type a message..."
              className="flex-1 bg-gray-800 text-white rounded-l-md px-4 py-2 focus:outline-none"
            />
            <button
              className="bg-blue-600 text-white px-4 rounded-r-md hover:bg-blue-700 transition-colors"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 2L11 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
